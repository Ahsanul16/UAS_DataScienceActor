# Proyek Klasifikasi Gender Aktor
Prediksi gender berdasarkan nama aktor.